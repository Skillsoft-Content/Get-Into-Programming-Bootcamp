//this is a comment
printOut = "Hello!"
//

