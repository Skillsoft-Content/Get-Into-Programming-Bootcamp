let printOut="";
//do not change the line above
//
printOut = "asdf";
//do not change the lines above
function showOutput(){
  document.getElementById("js_output").innerHTML=printOut;
}
