let printOut="";
//do not change the line above
//
printOut = "test";
//
//do not change the lines below
function showOutput(){
  document.getElementById("js_output").innerHTML=printOut;
}
